/* 
    helpers.h

    Description:
    Header file for the helper functions.
    
    Author: 
    Kohdy Nicholson
    
    Date: 
    2020-05-06
*/

int isprime(int number);
int isfib(int number);